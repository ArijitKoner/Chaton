package com.example.arijit.chaton;

import java.util.Date;

/**
 * Created by Arijit on 10/8/17.
 */

public class ChatMessage {
    private String message_txt;
    private String message_user;
    private long message_time;


    public ChatMessage(String message_txt, String message_user) {
        this.message_txt = message_txt;
        this.message_user = message_user;

        message_time = new Date().getTime();
    }

    public ChatMessage(String message_txt) {
        this.message_txt = message_txt;
    }

    public String getMessage_txt() {
        return message_txt;
    }

    public void setMessage_txt(String message_txt) {
        this.message_txt = message_txt;
    }

    public String getMessage_user() {
        return message_user;
    }

    public void setMessage_user(String message_user) {
        this.message_user = message_user;
    }

    public long getMessage_time() {
        return message_time;
    }

    public void setMessage_time(long message_time) {
        this.message_time = message_time;
    }
}
